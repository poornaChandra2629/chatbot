package com.wipro.trs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import com.wipro.trs.bean.TrainBean;
import com.wipro.trs.bean.InsertFare;
import com.wipro.trs.bean.InsertSeat;
import com.wipro.trs.bean.InsertTrain;
import com.wipro.trs.util.TrainDBUtill;

public class TrainDAo {
	List<String> TrainListNo=new ArrayList<String>();
	List<String> TrainListNames=new ArrayList<String>();
	List<String> ArrivalTime=new ArrayList<String>();
	List<String> DepartTime=new ArrayList<String>();

	public String insertNewUser(TrainBean bean)
	{
		String insertStatus="";
		try {
			Connection connection = TrainDBUtill.getDBConnection();
			String query = "insert into trs_tbl_Passengers values(?,?,?,?,?,?)";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, bean.getFn());
			preparedStatement.setString(2, bean.getLn());
			preparedStatement.setString(3, bean.getEmail());
			preparedStatement.setString(4, bean.getPhone());
			preparedStatement.setString(5, bean.getPwd());
			preparedStatement.setString(6, bean.getCpwd());
			int rs=preparedStatement.executeUpdate();
			if(rs==1)
			{
				insertStatus="Success";
			}
			else
			{
				insertStatus="Fail";
			}
			connection.close();
			preparedStatement.close();
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
		return insertStatus;
	}
	public String CheckUser(String uname,String pwd)
	{
		try
		{
			Connection connection = TrainDBUtill.getDBConnection();
			String query = "select Password from trs_tbl_Passengers where Phone=?";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1,uname);
			ResultSet rs=preparedStatement.executeQuery();
			rs.next();
			if(rs.getString("Password").equals(pwd))
			{
				return "Success";
			}
			connection.close();
			preparedStatement.close();
			
	}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
		return "Fail";
}
	public String Reset(String pwd,String cpwd,String phone)
	{
		try
		{
			Connection connection = TrainDBUtill.getDBConnection();
			String query = "update trs_tbl_Passengers set Password=?,ConfirmPassword=? where Phone=?";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1,pwd);
			preparedStatement.setString(2,cpwd);
			preparedStatement.setString(3,phone);
			int result=preparedStatement.executeUpdate();
			if(result==1)
			{
				return "Success";
			}
			connection.close();
			preparedStatement.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return "Fail";
	}
	public List<String> fromPlaces()
	{
		List<String> formlist=new ArrayList<String>();
		try {
			Connection connection = TrainDBUtill.getDBConnection();
			String query = "select * from trs_tbl_TrainDetails";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			ResultSet rs=preparedStatement.executeQuery();
			while(rs.next())
			{
				formlist.add(rs.getString("fromplaces")+","+rs.getString("Toplaces"));
			}
			connection.close();
			preparedStatement.close();
		}catch(Exception e)
		{
			System.out.println(e);
		}
		return formlist;
	}
	public List<String> trainDetails(String[] details)
	{
		List<String> trainDetails=new ArrayList<String>();
		try {
			Connection connection = TrainDBUtill.getDBConnection();
			String query = "select * from trs_tbl_TrainDetails where fromPlaces=? and toPlaces=? and dateoftrain=?";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1,details[1]);
			preparedStatement.setString(2,details[2]);
			preparedStatement.setString(3,details[0]);
			ResultSet rs=preparedStatement.executeQuery();
			while(rs.next())
			{
				trainDetails.add(rs.getString("trainNo")+","+rs.getString("TrainNames")+","+rs.getString("ArrivalTime")+","+rs.getString("DepartTime"));
			}
			connection.close();
			preparedStatement.close();
		}catch(Exception e)
		{
			System.out.println(e);
		}
		return trainDetails;
	}
	public int[] seats(String trainNo)
	{
		int[] seats=new int[6];
		try {
			Connection connection = TrainDBUtill.getDBConnection();
			String query = "select * from trs_tbl_seats where trainno=?";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setInt(1, Integer.parseInt(trainNo));
			ResultSet rs=preparedStatement.executeQuery();
			while(rs.next())
			{
				
				seats[0]=rs.getInt("t1ac");
				seats[1]=rs.getInt("t2ac");
				seats[2]=rs.getInt("t3ac");
				seats[3]=rs.getInt("sleeper");
				seats[4]=rs.getInt("general");
			}
			connection.close();
			preparedStatement.close();
		}catch(Exception e)
		{
			System.out.println(e);
		}
		return seats;
	}
	public String confirmSeats(String[] alldetails,String[] seatdetails)
	{
		String seats="";
		try {
			Connection connection = TrainDBUtill.getDBConnection();
			String query = "select * from trs_tbl_ticket where trainno=? and type=?";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setInt(1, Integer.parseInt(alldetails[0]));
			preparedStatement.setString(2, seatdetails[0].toLowerCase());
			ResultSet rs=preparedStatement.executeQuery();
			while(rs.next())
			{
			seats=seats+rs.getString("seats");
			}
			connection.close();
			preparedStatement.close();
		}catch(Exception e)
		{
			System.out.println(e);
		}
		return seats;
	}
	public String TrianName(String[] data1)
	{
		String name="";
		try {
			Connection connection = TrainDBUtill.getDBConnection();
			String query = "select trainnames from trs_tbl_TrainDetails where trainno=?";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setInt(1,Integer.parseInt(data1[0]));
			ResultSet rs=preparedStatement.executeQuery();
			rs.next();
			name=name+rs.getString("trainnames");
			connection.close();
			preparedStatement.close();
		}catch(Exception e)
		{
			System.out.println(e);
		}
		return name;
	}
	public String CheckUserPresence(TrainBean bean)
	{
		try
		{
			Connection connection = TrainDBUtill.getDBConnection();
			String query = "select * from trs_tbl_Passengers where phone=?";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, bean.getPhone());
			ResultSet rs=preparedStatement.executeQuery();
			if(!(bean.getCpwd().equals(bean.getPwd())))
			{
				return "Password";
			}
			if(rs.next())
			{
				return "Already user is there";
			}
			connection.close();
			preparedStatement.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
		return "";
	}
	public String Resetting(String phone,String email,String lname)
	{
		try
		{
			Connection connection = TrainDBUtill.getDBConnection();
			String query = "select * from trs_tbl_Passengers where phone=?";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, phone);
			ResultSet rs=preparedStatement.executeQuery();
			rs.next();
			if(rs.getString("email").equals(email) && rs.getString("LastName").equals(lname))
			{
				return "Success";
			}
			connection.close();
			preparedStatement.close();
			
	}
		catch(Exception e)
		{
			System.out.println(e);
		}
	return "Invalid Deatils!";
	}
	public void updateSeats(int trainno,String type,int seats)
	{
		try
		{
			Connection connection = TrainDBUtill.getDBConnection();
			String query = "update trs_tbl_seats set "+type+"=? where trainno=?";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setInt(1,seats);
			preparedStatement.setInt(2,trainno);
			int r=preparedStatement.executeUpdate();
			if(r==0)
			{
				System.out.println("error");
			}
			connection.close();
			preparedStatement.close();
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
	public void updateticketDetails(String data1[],String name,String transid,String pnr)
	{
		try
		{
			Connection connection = TrainDBUtill.getDBConnection();
			String query = "insert into trs_tbl_ticketdetails(trainno,trainname,dateofbooking,fromplace,toplace,name,phone,age,gender,type,adults,childs,seats,transid,pnrno,status) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setInt(1,Integer.parseInt(data1[0]));
			preparedStatement.setString(2, name);
			preparedStatement.setString(3,data1[1]);
			preparedStatement.setString(4, data1[2]);
			preparedStatement.setString(5, data1[3]);
			preparedStatement.setString(6, data1[4]);
			preparedStatement.setString(7, data1[5]);
			preparedStatement.setInt(8, Integer.parseInt(data1[6]));
			preparedStatement.setString(9, data1[7]);
			preparedStatement.setString(10, data1[8]);
			preparedStatement.setInt(11,Integer.parseInt(data1[9]));
			preparedStatement.setInt(12,Integer.parseInt(data1[10]));
			preparedStatement.setString(13, data1[12]);
			preparedStatement.setString(14, transid);
			preparedStatement.setString(15, pnr);
			preparedStatement.setString(16,"Booked");
			int n=preparedStatement.executeUpdate();
			if(n==0)
			{
				System.out.println("error");
			}
			connection.close();
			preparedStatement.close();
			
		}catch(Exception e)
		{
			System.out.println(e);
		}
	}
	public void updateticket(String data1[])
	{
		try
		{
			Connection connection = TrainDBUtill.getDBConnection();
			String query = "insert into trs_tbl_ticket values(?,?,?,?,?,?,?,?,?)";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setInt(1,Integer.parseInt(data1[0]));
			preparedStatement.setString(2, data1[4]);
			preparedStatement.setString(3,data1[5]);
			preparedStatement.setInt(4,( Integer.parseInt(data1[9])+Integer.parseInt(data1[10])));
			preparedStatement.setString(5, data1[8].toLowerCase());
			preparedStatement.setString(6, data1[12]);
			preparedStatement.setInt(7, Integer.parseInt(data1[13]));
			preparedStatement.setString(8, data1[2]);
			preparedStatement.setString(9, data1[1]);
			int n=preparedStatement.executeUpdate();
			if(n==0)
			{
				System.out.println("error");
			}
			connection.close();
			preparedStatement.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
	public int Fare(int trainno,String type)
	{
		int n=0;
		try
		{
			Connection connection = TrainDBUtill.getDBConnection();
			String query = "select * from trs_tbl_fare where trainno=? and type=?";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setInt(1, trainno);
			preparedStatement.setString(2, type.toLowerCase());
			ResultSet rs=preparedStatement.executeQuery();
			while(rs.next())
			{
				n=rs.getInt("fare");
			}
			connection.close();
			preparedStatement.close();
			
		}catch(Exception e)
		{
			System.out.println(e);
		}
		return n;
	}
	public String TrainTimeanddistance(int trainno)
	{
		String name="";
		try {
			Connection connection = TrainDBUtill.getDBConnection();
			String query = "select departtime,distance from trs_tbl_TrainDetails where trainno=?";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setInt(1,trainno);
			ResultSet rs=preparedStatement.executeQuery();
			rs.next();
			name=name+rs.getString("departtime")+","+rs.getInt("distance");
			connection.close();
			preparedStatement.close();
		}catch(Exception e)
		{
			System.out.println(e);
		}
		return name;
	}
	public int DeleteUser(String phone)
	{
		int n=-1;
		try {
			Connection connection = TrainDBUtill.getDBConnection();
			String query = "delete from trs_tbl_passengers where phone=?";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1,phone);
			n=preparedStatement.executeUpdate();
			connection.close();
			preparedStatement.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return n;
	}
	public List<String> viewPassengers()
	{
		List<String> view=new ArrayList<String>();
		try {
			Connection connection = TrainDBUtill.getDBConnection();
			String query = "select * from trs_tbl_Passengers";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			ResultSet rs=preparedStatement.executeQuery();
			while(rs.next())
			{
				view.add(rs.getString("firstname")+","+rs.getString("Lastname")+","+rs.getString("email")+","+rs.getString("phone"));
			}
			connection.close();
			preparedStatement.close();
		}catch(Exception e)
		{
			System.out.println(e);
		}
		return view;
	}
	public List<String> viewTickets()
	{
		List<String> view=new ArrayList<String>();
		try {
			Connection connection = TrainDBUtill.getDBConnection();
			String query = "select * from trs_tbl_ticketdetails";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			ResultSet rs=preparedStatement.executeQuery();
			while(rs.next())
			{
				view.add(rs.getInt("trainno")+","+rs.getString("trainname")+","+rs.getString("dateofbooking")+","+rs.getString("fromplace")+","+rs.getString("toplace")+","+rs.getString("name")+","+rs.getString("phone")+","+rs.getInt("age")+","+rs.getString("gender")+","+rs.getString("type")+","+rs.getInt("adults")+","+rs.getInt("childs")+","+rs.getString("seats")+","+rs.getString("transId")+","+rs.getString("pnrno")+","+rs.getString("status"));
			}
			connection.close();
			preparedStatement.close();
		}catch(Exception e)
		{
			System.out.println(e);
		}
		return view;
	}
	public int InsertTraindetails(InsertTrain isb)
	{
		try {
			Connection connection = TrainDBUtill.getDBConnection();
			String query = "select * from trs_tbl_traindetails where trainno=?";
			PreparedStatement preparedStatement1 = connection.prepareStatement(query);
			preparedStatement1.setInt(1,isb.getTrainno());
			ResultSet rs=preparedStatement1.executeQuery();
			if(rs.getRow()>0)
			{
				return 0;
			}
			connection.close();
			preparedStatement1.close();
		}catch(Exception e)
		{
			System.out.println(e);
		}
		int n=0;
		try {
			Connection connection = TrainDBUtill.getDBConnection();
			String query = "insert into trs_tbl_traindetails values(?,?,?,?,?,?,?,?)";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setInt(1,isb.getTrainno());
			preparedStatement.setString(2, isb.getTrainname());
			preparedStatement.setString(3,isb.getDateoftrain());
			preparedStatement.setString(4,isb.getArrivaltime());
			preparedStatement.setString(5, isb.getDeparttime());
			preparedStatement.setString(6, isb.getFromplace());
			preparedStatement.setString(7, isb.getToplace());
			preparedStatement.setInt(8, isb.getDistance());
			n=preparedStatement.executeUpdate();
			connection.close();
			preparedStatement.close();
		}catch(Exception e)
		{
			System.out.println(e);
		}
		return n;
	}
	public int insertSeat(InsertSeat isb)
	{
		int n=0;
		try {
			Connection connection = TrainDBUtill.getDBConnection();
			String query = "insert into trs_tbl_seats values(?,?,?,?,?,?)";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setInt(1, isb.getTrainno());
			preparedStatement.setInt(2, isb.getT1ac());
			preparedStatement.setInt(3, isb.getT2ac());
			preparedStatement.setInt(4, isb.getT3ac());
			preparedStatement.setInt(5, isb.getSleeper());
			preparedStatement.setInt(6, isb.getGeneral());
			n=preparedStatement.executeUpdate();
			connection.close();
			preparedStatement.close();
		}catch(Exception e)
		{
			System.out.println(e);
		}
		return n;
	}
	
	public int insertFare(InsertFare isb)
	{
		int n=0;
		try {
			Connection connection = TrainDBUtill.getDBConnection();
			String query = "insert into trs_tbl_fare values(?,?,?)";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setInt(1, isb.getTrainno());
			preparedStatement.setString(2, isb.getType());
			preparedStatement.setInt(3, isb.getFare());
			n=preparedStatement.executeUpdate();
			connection.close();
			preparedStatement.close();
		}catch(Exception e)
		{
			System.out.println(e);
		}
		return n;
	}
	public int updatetrain(int trainno,String at,String dt)
	{
		int n=0;
		try {
			Connection connection = TrainDBUtill.getDBConnection();
			String query = "update trs_tbl_traindetails set arrivaltime=?,departtime=? where trainno=?";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setInt(3, trainno);
			preparedStatement.setString(1, at);
			preparedStatement.setString(2, dt);
			n=preparedStatement.executeUpdate();
			connection.close();
			preparedStatement.close();
		}catch(Exception e)
		{
			System.out.println(e);
		}
		return n;
	}
	public int deletetrain(int trainno)
	{
		int n=0,n1=0,n2=0;
		try {
			Connection connection = TrainDBUtill.getDBConnection();
			String query = "delete trs_tbl_fare where trainno=?";
			String query1 = "delete trs_tbl_seats where trainno=?";
			String query2= "delete trs_tbl_traindetails where trainno=?";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			PreparedStatement preparedStatement1 = connection.prepareStatement(query1);
			PreparedStatement preparedStatement2 = connection.prepareStatement(query2);
			preparedStatement.setInt(1, trainno);
			preparedStatement1.setInt(1, trainno);
			preparedStatement2.setInt(1, trainno);
			n=preparedStatement.executeUpdate();
			n1=preparedStatement1.executeUpdate();
			n2=preparedStatement2.executeUpdate();
			connection.close();
			preparedStatement.close();
			preparedStatement1.close();
			preparedStatement2.close();
		}catch(Exception e)
		{
			System.out.println(e);
		}
		if(n==0 || n1==0 || n2==0)
		{
			n=0;
		}
		else
		{
			n=1;
		}
		return n;
	}
	public List<String> viewTicket(String phone)
	{
		List<String> mylist=new ArrayList<String>();
		try {
			Connection connection = TrainDBUtill.getDBConnection();
			String query = "select * from trs_tbl_ticket where phone=?";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, phone);
			ResultSet rs=preparedStatement.executeQuery();
			while(rs.next())
			{
				mylist.add(rs.getInt("trainno")+","+rs.getString("Passenger")+","+rs.getString("phone")+","+rs.getInt("noseats")+","+rs.getString("type")+","+rs.getString("seats")+","+rs.getInt("fare")+","+rs.getString("dateofbooking")+","+rs.getString("trainname"));
			}
			connection.close();
			preparedStatement.close();
		}catch(Exception e)
		{
			System.out.println(e);
		}
		return mylist;
	}
	public String cancelTicket(int trainno,String phone,String type,String seats,int noseats)
	{
		int n=0,n1=0,n2=0;
		try {
			Connection connection = TrainDBUtill.getDBConnection();
			String query ="delete trs_tbl_ticket where trainno=? and phone=? and type=? and seats=?";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setInt(1, trainno);
			preparedStatement.setString(2, phone);
			preparedStatement.setString(3, type);
			preparedStatement.setString(4, seats);
			n=preparedStatement.executeUpdate();
			//delete ticket from passengers list above code
			String q="select * from trs_tbl_seats where trainno=?"; 
			PreparedStatement p = connection.prepareStatement(q);
			p.setInt(1, trainno);
			ResultSet rs=p.executeQuery();
			rs.next();
			int t=rs.getInt(type);
			noseats=noseats+t;
			//getting seats from train above code;
			String query1 = "update trs_tbl_seats set "+type+"=? where trainno=?";
			PreparedStatement preparedStatement1 = connection.prepareStatement(query1);
			preparedStatement1.setInt(1, noseats);
			preparedStatement1.setInt(2, trainno);
			n1=preparedStatement1.executeUpdate();
			//update seats from train table above code
			String qu="update trs_tbl_ticketdetails set status=? where phone=? and trainno=?";
			PreparedStatement pu = connection.prepareStatement(qu);
			pu.setString(1, "Cancelled");
			pu.setInt(3, trainno);
			pu.setString(2, phone);
			n2=pu.executeUpdate();
			connection.close();
			preparedStatement.close();
			preparedStatement1.close();
			p.close();
			pu.close();
		}catch(Exception e)
		{
			System.out.println(e);
		}
		//System.out.println(n1+" "+n2+" "+n);
			if(n==0 || n1==0 ||n2==0)
			{
				
				return "wrong";
			}
			return "cancelled";
	}
	public List<String> trainDetailsAdmin()
	{
		List<String> myList=new ArrayList<String>();
		try {
			Connection connection = TrainDBUtill.getDBConnection();
			String query = "select * from trs_tbl_traindetails";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			ResultSet rs=preparedStatement.executeQuery();
			while(rs.next())
			{
				//System.out.println(rs.getInt("trainno"));
				myList.add(rs.getInt("trainno")+","+rs.getString("trainnames")+","+rs.getString("dateoftrain")+","+rs.getString("arrivaltime")+","+rs.getString("departtime")+","+rs.getString("fromplaces")+","+rs.getString("toplaces")+","+rs.getInt("distance"));		
			}
			connection.close();
			preparedStatement.close();
			
		}catch(Exception e)
		{
			System.out.println(e);
		}
		return myList;
	}
	
}
