package com.wipro.trs.bean;

public class TrainBean {

	String fn;
	String ln;
	String email;
	String phone;
	String pwd;
	String cpwd;
	public TrainBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public TrainBean(String fn,String ln,String email,String phone,String pwd,String cpwd)
	{
		this.fn=fn;
		this.ln=ln;
		this.email=email;
		this.phone=phone;
		this.pwd=pwd;
		this.cpwd=cpwd;
	}
	public void setFn(String fn)
	{
		this.fn=fn;
	}
	public void setLn(String ln)
	{
		this.ln=ln;
	}
	public void setEmail(String email)
	{
		this.email=email;
	}
	public void setPhone(String phone)
	{
		this.phone=phone;
	}
	public void setPwd(String pwd)
	{
		this.pwd=pwd;
	}
	public void setCpwd(String cpwd)
	{
		this.cpwd=cpwd;
	}
	public String getFn()
	{
		return fn;
	}
	public String getLn()
	{
		return ln;
	}
	public String getEmail()
	{
		return email;
	}
	public String getPhone()
	{
		return phone;
	}
	public String getPwd()
	{
		return pwd;
	}
	public String getCpwd()
	{
		return cpwd;
	}
	

}
