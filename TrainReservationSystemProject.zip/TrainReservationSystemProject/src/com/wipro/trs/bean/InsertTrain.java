package com.wipro.trs.bean;

public class InsertTrain {

	private int trainno;
	private String trainname;
	private String dateoftrain;
	private String arrivaltime;
	private String departtime;
	private String fromplace;
	private String toplace;
	private int distance;
	public InsertTrain(int trainno,String trainname,String dateoftrain,String arrivaltime,String departtime,String fromplace,String toplace,int distance) {
		// TODO Auto-generated constructor stub
		super();
		this.trainno=trainno;
		this.trainname=trainname;
		this.dateoftrain=dateoftrain;
		this.arrivaltime=arrivaltime;
		this.departtime=departtime;
		this.fromplace=fromplace;
		this.toplace=toplace;
		this.distance=distance;
	}
	public InsertTrain() {
		// TODO Auto-generated constructor stub
	}
	public int getTrainno() {
		return trainno;
	}
	public void setTrainno(int trainno) {
		this.trainno = trainno;
	}
	public String getTrainname() {
		return trainname;
	}
	public void setTrainname(String trainname) {
		this.trainname = trainname;
	}
	public String getDateoftrain() {
		return dateoftrain;
	}
	public void setDateoftrain(String dateoftrain) {
		this.dateoftrain = dateoftrain;
	}
	public String getArrivaltime() {
		return arrivaltime;
	}
	public void setArrivaltime(String arrivaltime) {
		this.arrivaltime = arrivaltime;
	}
	public String getDeparttime() {
		return departtime;
	}
	public void setDeparttime(String departtime) {
		this.departtime = departtime;
	}
	public String getFromplace() {
		return fromplace;
	}
	public void setFromplace(String fromplace) {
		this.fromplace = fromplace;
	}
	public String getToplace() {
		return toplace;
	}
	public void setToplace(String toplace) {
		this.toplace = toplace;
	}
	public int getDistance() {
		return distance;
	}
	public void setDistance(int distance) {
		this.distance = distance;
	}
 

}
