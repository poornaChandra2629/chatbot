package com.wipro.trs.bean;

public class InsertFare {
private int trainno;
private String type;
private int fare;
	public InsertFare() {
		// TODO Auto-generated constructor stub
	}
	public InsertFare(int trainno,String type,int fare) {
		// TODO Auto-generated constructor stub
		super();
		this.fare=fare;
		this.trainno=trainno;
		this.type=type;
	}
	public int getTrainno() {
		return trainno;
	}
	public void setTrainno(int trainno) {
		this.trainno = trainno;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public int getFare() {
		return fare;
	}
	public void setFare(int fare) {
		this.fare = fare;
	}

}
