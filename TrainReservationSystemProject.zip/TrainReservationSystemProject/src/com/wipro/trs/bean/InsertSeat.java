package com.wipro.trs.bean;

public class InsertSeat {
private int trainno;
private int t1ac;
private int t2ac;
private int t3ac;
private int sleeper;
private int general;
public InsertSeat(int trainno,int t1ac,int t2ac,int t3ac,int sleeper,int general)
{
	super();
	this.trainno=trainno;
	this.t1ac=t1ac;
	this.t2ac=t2ac;
	this.t3ac=t3ac;
	this.sleeper=sleeper;
	this.general=general;
}
	public int getTrainno() {
	return trainno;
}
public void setTrainno(int trainno) {
	this.trainno = trainno;
}
public int getT1ac() {
	return t1ac;
}
public void setT1ac(int t1ac) {
	this.t1ac = t1ac;
}
public int getT2ac() {
	return t2ac;
}
public void setT2ac(int t2ac) {
	this.t2ac = t2ac;
}
public int getT3ac() {
	return t3ac;
}
public void setT3ac(int t3ac) {
	this.t3ac = t3ac;
}
public int getSleeper() {
	return sleeper;
}
public void setSleeper(int sleeper) {
	this.sleeper = sleeper;
}
public int getGeneral() {
	return general;
}
public void setGeneral(int general) {
	this.general = general;
}
	public InsertSeat() {
		// TODO Auto-generated constructor stub
	}

}
