package com.wipro.trs.service;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

import com.wipro.trs.bean.InsertFare;
import com.wipro.trs.bean.InsertSeat;
import com.wipro.trs.bean.InsertTrain;
import com.wipro.trs.bean.TrainBean;
import com.wipro.trs.dao.TrainDAo;

public class TrainService {
public String insertPassenger(TrainBean bean)
{
	TrainDAo trainDa=new TrainDAo();
	String s=trainDa.CheckUserPresence(bean);
	if(s!="")
	{
		return s;
	}
	return trainDa.insertNewUser(bean);
}
public String CheckPassenger(String uname,String pwd)
{
	TrainDAo trainDa=new TrainDAo();
	if(uname.equals("9949310993") && pwd.equals("Admin@123"))
	{
		return "Hi Admin";
	}
	return trainDa.CheckUser(uname,pwd);
}
public String Reset(String phone,String email,String lname)
{
	TrainDAo trainDa=new TrainDAo();
	 String s=trainDa.Resetting(phone, email, lname);
	 return s;
}
public String Reseting(String pwd,String cpwd,String phone)
{
	TrainDAo trainDa=new TrainDAo();
	return trainDa.Reset(pwd, cpwd, phone);
	
}
public List<String> fromlist()
{
	TrainDAo trainDa=new TrainDAo();
	return trainDa.fromPlaces();
}
public List<String> trainDetails(String[] details)
{
	TrainDAo trainDa=new TrainDAo();
	return trainDa.trainDetails(details);
}
public int[] seats(String trainNo)
{
	TrainDAo trainDa=new TrainDAo();
	return trainDa.seats(trainNo);
}
public String confirmSeats(String[] alldetails,String[] seatdetails)
{
	TrainDAo trainDa=new TrainDAo();
	return trainDa.confirmSeats(alldetails, seatdetails);
}
public String TrianName(String[] data1)
{
	TrainDAo trainDa=new TrainDAo();
	return trainDa.TrianName(data1);
}
public void updateSeats(int trainno,String type,int seats)
{
	TrainDAo trainDa=new TrainDAo();
	trainDa.updateSeats(trainno, type, seats);
}
public void updateticketDetails(String data1[],String name,String transid,String pnr)
{
	TrainDAo trainDa=new TrainDAo();
	trainDa.updateticketDetails(data1, name, transid, pnr);
}
public void updateticket(String data1[])
{
	TrainDAo trainDa=new TrainDAo();
	trainDa.updateticket(data1);
}
public int Fare(int trainno,String type)
{
	TrainDAo trainDa=new TrainDAo();
	 return trainDa.Fare(trainno, type);
}
public String TrainTimeanddistance(int trainno)
{
	TrainDAo trainDa=new TrainDAo();
	 return  trainDa.TrainTimeanddistance(trainno);
}
public int DeleteUser(String phone)
{
	TrainDAo trainDa=new TrainDAo();
	return trainDa.DeleteUser(phone);
}
public List<String> viewPassengers()
{
	TrainDAo trainDa=new TrainDAo();
	return trainDa.viewPassengers();
}
public List<String> viewTickets()
{
	TrainDAo trainDa=new TrainDAo();
	return trainDa.viewTickets();
}
public int InsertTraindetails(InsertTrain isb)
{
	TrainDAo trainDa=new TrainDAo();
	return trainDa.InsertTraindetails(isb);
}
public int insertSeat(InsertSeat isb)
{
	TrainDAo trainDa=new TrainDAo();
	return trainDa.insertSeat(isb);
}
public int insertFare(InsertFare isb)
{
	TrainDAo trainDa=new TrainDAo();
	return trainDa.insertFare(isb);
}
public int updatetrain(int trainno,String at,String dt)
{
	TrainDAo trainDa=new TrainDAo();
	return trainDa.updatetrain(trainno, at, dt);
}
public int deletetrain(int trainno)
{
	TrainDAo trainDa=new TrainDAo();
	return trainDa.deletetrain(trainno);
}
public List<String> viewTicket(String phone)
{
	TrainDAo trainDa=new TrainDAo();
	return trainDa.viewTicket(phone);
}
public String cancelTicket(int trainno,String phone,String type,String seats,int noseats)
{
	TrainDAo trainDa=new TrainDAo();
	return trainDa.cancelTicket(trainno, phone,type,seats,noseats);
}
public List<String> trainDetailsAdmin()
{
	TrainDAo trainDa=new TrainDAo();
	return trainDa.trainDetailsAdmin();
}
}
