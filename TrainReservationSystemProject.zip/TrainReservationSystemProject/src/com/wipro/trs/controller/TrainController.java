package com.wipro.trs.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.wipro.trs.bean.InsertFare;
import com.wipro.trs.bean.InsertSeat;
import com.wipro.trs.bean.InsertTrain;
import com.wipro.trs.bean.TrainBean;
import com.wipro.trs.service.TrainService;

public class TrainController extends HttpServlet {
    @Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
    	String trigerFrom = request.getParameter("Button");
    	if(trigerFrom.equals("SignUp"))
    	{
    		String passfn=request.getParameter("Fname");
    		String passln=request.getParameter("Lname");
    		String email=request.getParameter("Email");
    		String phone=request.getParameter("Phone");
    		String pwd=request.getParameter("Pwd");
    		String cpwd=request.getParameter("Cpwd");
    		
    		TrainBean bean=new TrainBean();
    		bean.setFn(passfn);
    		bean.setLn(passln);
    		bean.setEmail(email);
    		bean.setPhone(phone);
    		bean.setPwd(pwd);
    		bean.setCpwd(cpwd);
    		TrainService trainService=new TrainService();
    		String result=trainService.insertPassenger(bean);
    		if(result.equals("Success"))
    		{
    			response.sendRedirect("FinalSignup.jsp");
    		}
    		else if(result.equals("Fail"))
    		{
    			response.sendRedirect("SignupFail.jsp");
    		}
    		else if(result.equals("Password"))
    		{
    			response.sendRedirect("PasswordFail.jsp");
    		}
    		else
    		{
    			response.sendRedirect("Existinguser.jsp");
    		}
    		

    	}
    	if(trigerFrom.equals("Login"))
    	{
    		String uname=request.getParameter("Uname");
    		String pwd=request.getParameter("Pwd");
    		TrainService trainService=new TrainService();
    		String result=trainService.CheckPassenger(uname,pwd);
    		if(result.equals("Success"))
    		{
    			 HttpSession session = request.getSession(true);
    			 session.setAttribute("user", uname);
    			 session.setMaxInactiveInterval(30);
    			 request.setAttribute("uname", uname);
    			 request.getRequestDispatcher("UserPageAfterLogin.jsp").forward(request, response);
    		}
    		else if(result.equals("Fail"))
    		{
    			response.sendRedirect("LoginFail.jsp");

    		}
    		else
    		{
    			HttpSession session = request.getSession(true);
   			 session.setAttribute("user", uname);
   			 session.setMaxInactiveInterval(30);
    			response.sendRedirect("AdminPageAfterLogin.jsp");
    		}
 
    	}
    	if(trigerFrom.equals("Forgot"))
    	{
    		String phone=request.getParameter("Phone");
    		String email=request.getParameter("Email");
    		String lname=request.getParameter("Lastname");
    		TrainService trainService=new TrainService();
    		String result=trainService.Reset(phone,email,lname);
    		if(result.equals("Invalid Deatils!"))
    		{
    			response.sendRedirect("ForgotFail.jsp");
    		}
    		else
    		{
    			response.sendRedirect("ForgotSuccess.jsp");
    		}
    		
    		
    	}
    	if(trigerFrom.equals("Reseting"))
    	{
    		String pwd=request.getParameter("Pwd");
    		String cpwd=request.getParameter("Cpwd");
    		String phone=request.getParameter("Phone");
    		TrainService trainService=new TrainService();
    		String result=trainService.Reseting(pwd,cpwd,phone);
    		if(result.equals("Success"))
    		{
    			response.sendRedirect("ResetSuccess.jsp");
    		}
    		else
    		{
    			response.sendRedirect("ResetFail.jsp");
    		}
    	}
    	if(trigerFrom.equals("Logout"))
    	{
    		HttpSession session = request.getSession(false);
    	      session.removeAttribute("user");
    	      session.getMaxInactiveInterval();
    	      response.sendRedirect("logout.jsp");
    		
    	}
    	if(trigerFrom.equals("Delete"))
    	{
    		String phone=request.getParameter("phone");
    		TrainService trainService=new TrainService();
    		int res=trainService.DeleteUser(phone);
    		//System.out.println(res);
    		request.setAttribute("res", res);
    		request.getRequestDispatcher("deletePassengersuccessorfail.jsp").forward(request, response);
    	}
    	if(trigerFrom.equals("viewpassengers"))
    	{
    		TrainService trainService=new TrainService();
    		List<String> res=trainService.viewPassengers();
    		List<String> fn=new ArrayList<String>();
    		List<String> ln=new ArrayList<String>();
    		List<String> email=new ArrayList<String>();
    		List<String> phone=new ArrayList<String>();
    		Iterator itr=res.iterator();
    		while(itr.hasNext())
    		{
    			String t=(String)itr.next();
    			String[] t1=t.split(",");
    			fn.add(t1[0]);
    			ln.add(t1[1]);
    			email.add(t1[2]);
    			phone.add(t1[3]);
    		}
    		
    		request.setAttribute("fn", fn);
    		request.setAttribute("ln", ln);
    		request.setAttribute("email", email);
    		request.setAttribute("phone", phone);
    		request.getRequestDispatcher("viewAllPassengers.jsp").forward(request, response);
    	}
    	if(trigerFrom.equals("viewTickets"))
    	{
    		TrainService trainService=new TrainService();
    		List<String> view=trainService.viewTickets();
    		//System.out.println(view.get(0));
    		request.setAttribute("tickets", view);
    		request.getRequestDispatcher("viewTicket.jsp").forward(request, response);
    	}
    	if(trigerFrom.equals("InsertTrain"))
    	{
    		TrainService ts=new TrainService();
    		String[] traindetails=new String[8];
    		traindetails[0]=request.getParameter("Trainno");
    		traindetails[1]=request.getParameter("Trainname");
    		traindetails[2]=request.getParameter("Dateoftrain");
    		traindetails[3]=request.getParameter("Arrivaltime");
    		traindetails[4]=request.getParameter("Departuretime");
    		traindetails[5]=request.getParameter("From");
    		traindetails[6]=request.getParameter("To");
    		traindetails[7]=request.getParameter("Distance");
    		InsertTrain is=new InsertTrain();
    		is.setTrainno(Integer.parseInt(traindetails[0]));
    		is.setTrainname(traindetails[1]);
    		is.setDateoftrain(traindetails[2]);
    		is.setArrivaltime(traindetails[3]);
    		is.setDeparttime(traindetails[4]);
    		is.setFromplace(traindetails[5]);
    		is.setToplace(traindetails[6]);
    		is.setDistance(Integer.parseInt(traindetails[7]));
    		int n=ts.InsertTraindetails(is);
    		if(n==1)
    		{
    			request.setAttribute("Trainno", traindetails[0]);
        		request.getRequestDispatcher("insertSeats.jsp").forward(request, response);
    		}
    		else
    		{
    			response.sendRedirect("InsertTrainFail.jsp");
    		}
    	}
    	
    	if(trigerFrom.equals("insertSeat"))
    	{
    		TrainService ts=new TrainService();
    		String[] traindetails=new String[6];
    		traindetails[0]=request.getParameter("Trainno");
    		traindetails[1]=request.getParameter("T1ac");
    		traindetails[2]=request.getParameter("T2ac");
    		traindetails[3]=request.getParameter("T3ac");
    		traindetails[4]=request.getParameter("Sleeper");
    		traindetails[5]=request.getParameter("General");
    		InsertSeat is=new InsertSeat();
    		is.setTrainno(Integer.parseInt(traindetails[0]));
    		is.setT1ac(Integer.parseInt(traindetails[1]));
    		is.setT2ac(Integer.parseInt(traindetails[2]));
    		is.setT3ac(Integer.parseInt(traindetails[3]));
    		is.setSleeper(Integer.parseInt(traindetails[4]));
    		is.setGeneral(Integer.parseInt(traindetails[5]));
    		int res=ts.insertSeat(is);
    		if(res==1)
    		{
    			request.setAttribute("Trainno", traindetails[0]);
        		request.getRequestDispatcher("insertfare.jsp").forward(request, response);
    		}
    		else
    		{
    			response.sendRedirect("insertSeatsfail.jsp");
    		}
    		
    	}
    	if(trigerFrom.equals("insertfare"))
    	{
    		String[] traintype=new String[] {"t1ac","t2ac","t3ac","sleeper","general"};
    		TrainService ts=new TrainService();
    		String[] traindetails=new String[6];
    		traindetails[0]=request.getParameter("Trainno");
    		traindetails[1]=request.getParameter("T1ac");
    		traindetails[2]=request.getParameter("T2ac");
    		traindetails[3]=request.getParameter("T3ac");
    		traindetails[4]=request.getParameter("Sleeper");
    		traindetails[5]=request.getParameter("General");
    		InsertFare is=new InsertFare();
    		for(int i=1;i<=5;i++)
    		{
    			is.setTrainno(Integer.parseInt(traindetails[0]));
    			is.setType(traintype[i-1]);
    			is.setFare(Integer.parseInt(traindetails[i]));
    			int n=ts.insertFare(is);
    			if(n==0)
    			{
    				response.sendRedirect("Insertfarefail.jsp");
    			}
    		}
    		response.sendRedirect("AdminPageAfterLogin.jsp");
    	}
    	if(trigerFrom.equals("updatetrain"))
    	{
    		TrainService ts=new TrainService();
    		String[] traindetails=new String[3];
    		traindetails[0]=request.getParameter("Trainno");
    		traindetails[1]=request.getParameter("Arrivaltime");
    		traindetails[2]=request.getParameter("Departuretime");
    		int n=ts.updatetrain(Integer.parseInt(traindetails[0]), traindetails[1], traindetails[2]);
    		if(n==0)
    		{
    			response.sendRedirect("updatetrainfail.jsp");
    		}
    		else
    		{
    			response.sendRedirect("AdminPageAfterLogin.jsp");
    		}

    		
    	}
    	if(trigerFrom.equals("deletetrain"))
    	{
    		TrainService ts=new TrainService();
    		int n=0;
    		String s=request.getParameter("Trainno");
    		n=ts.deletetrain(Integer.parseInt(s));
    		if(n==0)
    		{
    			response.sendRedirect("deletetrainfail.jsp");
    		}
    		else
    		{
    			response.sendRedirect("AdminPageAfterLogin.jsp");
    		}
    	}
    	if(trigerFrom.equals("trainDetails"))
    	{
    		TrainService ts=new TrainService();
    		List<String> mylist=ts.trainDetailsAdmin();
    		request.setAttribute("Traindetails", mylist);
    		request.getRequestDispatcher("traindetails.jsp").forward(request, response);
    	}
	}

}
