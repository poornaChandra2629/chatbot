package com.wipro.trs.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wipro.trs.service.TrainService;

public class CustomerTrainController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String trigerFrom = request.getParameter("Button");
		String[] details=new String[10];
    	if(trigerFrom.equals("Book"))
    	{
    		List<String> fromlist=new ArrayList<String>();
    		List<String> tolist=new ArrayList<String>();
    		TrainService s=new TrainService();
    		List<String> list=s.fromlist();
    		Iterator itr=list.iterator();
    		while(itr.hasNext())
    		{
    			String temp=(String) itr.next();
    			String[] temp1=temp.split(",");
    			fromlist.add(temp1[0]);
    			tolist.add(temp1[1]);
    			
    		}
    		request.setAttribute("Fromlist", fromlist);  
    		request.setAttribute("Tolist", tolist);
    		request.getRequestDispatcher("BookingPage.jsp").forward(request, response);
    	}
    	if(trigerFrom.equals("Selecting"))
    	{
    		List<String> TrainListNo=new ArrayList<String>();
    		List<String> TrainListNames=new ArrayList<String>();
    		List<String> ArrivalTime=new ArrayList<String>();
    		List<String> DepartTime=new ArrayList<String>();
    		String main =  request.getParameter("main");
    		details = main.split(",");
    		TrainService s=new TrainService();
    		List<String> list=s.trainDetails(details);
    		Iterator it=list.iterator();
    		while(it.hasNext())
    		{
    			String t=(String) it.next();
    			String[] sp=t.split(",");
    			TrainListNo.add(sp[0]);
    			TrainListNames.add(sp[1]);
    			ArrivalTime.add(sp[2]);
    			DepartTime.add(sp[3]);
    		}
    		request.setAttribute("main", main);
    		request.setAttribute("TrainListNo", TrainListNo);   
    		request.setAttribute("TrainListNames", TrainListNames);  
    		request.setAttribute("ArrivalTime", ArrivalTime);  
    		request.setAttribute("DepartTime", DepartTime);    
    		request.getRequestDispatcher("trainTable.jsp").forward(request, response);	
    	}
    	if(trigerFrom.equals("Clickhere"))
    	{
    		TrainService s=new TrainService();
    		String trainNo  =  request.getParameter("TrainDetails");
    		int[] seats=s.seats(trainNo);
    		String main=request.getParameter("submain");
    		main=trainNo+","+main;
    		request.setAttribute("main1",main);
       		request.setAttribute("trainNo", trainNo);
    		request.setAttribute("seats", seats);    
    		request.getRequestDispatcher("seatsAvaliability.jsp").forward(request, response);	
    	}
    	if(trigerFrom.equals("Details"))
    	{
    		TrainService s=new TrainService();
    		String confirmSeats="";
    		String main2=request.getParameter("seatdetails");
    		String main1=request.getParameter("alldetails");
    		String[] seatdetails=main2.split(",");
    		String[] alldetails=main1.split(",");
    		String seats=s.confirmSeats(alldetails, seatdetails);
    		for(int i=1;i<=Integer.parseInt(seatdetails[1])+Integer.parseInt(seatdetails[2]);i++)
    		{
    			for(int j=1;j<=999;j++)
    			{
    				String t=Integer.toString(j);
    				if(!seats.contains(t))
    				{
    					confirmSeats=confirmSeats+t+":";
    					seats=seats+":"+t;
    					break;
    				}
    			}
    			
    		}
    		confirmSeats=confirmSeats.substring(0,confirmSeats.length()-1);
    		int fare=s.Fare(Integer.parseInt(alldetails[0]),seatdetails[0]);
    		fare= (Integer.parseInt(seatdetails[1])+Integer.parseInt(seatdetails[2]))*fare;
    		String data=main1+","+main2+","+confirmSeats+","+Integer.toString(fare);
    		request.setAttribute("fare", fare);
    		request.setAttribute("confirmSeats", confirmSeats);
    		request.setAttribute("main1",data );
    		request.setAttribute("seatdetails", seatdetails);
    		request.setAttribute("alldetails", alldetails);
    		request.getRequestDispatcher("FinalSeating.jsp").forward(request, response);	
    	}
    	
    	if(trigerFrom.equals("Done"))
    	{
    		TrainService s=new TrainService();
    		String data=request.getParameter("data");
    		String[] data1=data.split(",");
    		String transid="";
    		String pnr="";
    		String name=s.TrianName(data1);
    		for(int i=0;i<13;i++)
    		{
    			int n= (int) ((Math.random()*((9-0)+1))+0);
    			transid=transid+Integer.toString(n);
    		}
    		for(int i=0;i<15;i++)
    		{
    			int n= (int) ((Math.random()*((9-0)+1))+0);
    			pnr=pnr+Integer.toString(n);
    		}
    		int seats=Integer.parseInt(data1[11])-(Integer.parseInt(data1[9])+Integer.parseInt(data1[10]));
    		String td=s.TrainTimeanddistance(Integer.parseInt(data1[0]));
    		String[] timeanddistance=td.split(",");
    		s.updateSeats(Integer.parseInt(data1[0]), data1[8],seats );
    		s.updateticketDetails(data1, name, transid, pnr);
    		s.updateticket(data1);
    		request.setAttribute("timeanddistance", timeanddistance);
    		request.setAttribute("data", data1);
    		request.setAttribute("name", name);
    		request.setAttribute("transid", transid);
    		request.setAttribute("pnr", pnr);
    		request.getRequestDispatcher("ticket.jsp").forward(request, response);
    		
    	}
    	if(trigerFrom.equals("Show"))
    	{
    		TrainService s=new TrainService();
    		String data=request.getParameter("uname");
    		List<String> mylist=s.viewTicket(data);
    		request.setAttribute("mylist", mylist);
    		request.getRequestDispatcher("passengerticket.jsp").forward(request, response);
    	}
    	if(trigerFrom.equals("Cancel"))
    	{
    		TrainService s=new TrainService();
    		String data=request.getParameter("uname");
    		List<String> mylist=s.viewTicket(data);
    		request.setAttribute("mylist", mylist);
    		request.setAttribute("uname", data);
    		request.getRequestDispatcher("cancelTicket.jsp").forward(request, response);
    	}
    	if(trigerFrom.equals("cancelTicket"))
    	{
    		TrainService s=new TrainService();
    		String data1=request.getParameter("TrainDetails");
    		String type=request.getParameter("type");
    		String seats=request.getParameter("seats");
    		String data=request.getParameter("uname");
    		String noseats=request.getParameter("noseats");
    		String n=s.cancelTicket(Integer.parseInt(data1),data,type,seats,Integer.parseInt(noseats));
    		request.setAttribute("status", n);
    		request.getRequestDispatcher("cancelticketstatus.jsp").forward(request, response);
    		
    	}
    	if(trigerFrom.equals("PRINT"))
    	{ 
    		response.sendRedirect("UserPageAfterLogin.jsp");
    	}
	}

}
